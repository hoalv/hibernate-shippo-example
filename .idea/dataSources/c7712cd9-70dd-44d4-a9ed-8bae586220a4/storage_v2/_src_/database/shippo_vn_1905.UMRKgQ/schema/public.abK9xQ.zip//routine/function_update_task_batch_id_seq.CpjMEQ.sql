create function function_update_task_batch_id_seq()
  returns trigger
language plpgsql
as $$
BEGIN
         perform pg_catalog.setval('task_batch_id_seq', (select max("id") from "TaskBatch"));
				 RETURN NEW;
END;
$$;

