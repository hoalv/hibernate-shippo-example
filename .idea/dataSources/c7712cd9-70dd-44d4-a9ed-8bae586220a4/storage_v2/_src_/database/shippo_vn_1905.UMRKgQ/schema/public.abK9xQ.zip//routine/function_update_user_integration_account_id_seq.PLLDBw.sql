create function function_update_user_integration_account_id_seq()
  returns trigger
language plpgsql
as $$
BEGIN
         perform pg_catalog.setval('user_integration_account_id_seq', (select max("id") from "UserIntegrationAccount"));
				 RETURN NEW;
END;
$$;

