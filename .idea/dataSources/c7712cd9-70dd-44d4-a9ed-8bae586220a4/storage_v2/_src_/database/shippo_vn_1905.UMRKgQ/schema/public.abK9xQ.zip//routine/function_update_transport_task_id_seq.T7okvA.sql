create function function_update_transport_task_id_seq()
  returns trigger
language plpgsql
as $$
BEGIN
         perform pg_catalog.setval('transport_task_id_seq', (select max("id") from "TransportTask"));
				 RETURN NEW;
END;
$$;

