create function function_update_users_id_seq()
  returns trigger
language plpgsql
as $$
BEGIN
         perform pg_catalog.setval('users_id_seq', (select max("id") from "Users"));
				 RETURN NEW;
END;
$$;

